
import { GoogleGenAI } from "@google/genai";

// Generate poetic descriptions for properties using Gemini 3
export const getArchitecturalInsight = async (propertyName: string) => {
  // Create a new instance right before making an API call to ensure it uses the most up-to-date API key.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide a short, 2-sentence poetic luxury real estate description for a building named ${propertyName} that embodies the Arabic meaning of 'Emaar' (building and flourishing).`,
      config: {
        temperature: 0.8,
        topP: 0.95,
      }
    });
    // Use .text property directly to extract the string output.
    return response.text || "A testament to prosperity and enduring vision.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Crafting legends in glass and stone.";
  }
};
