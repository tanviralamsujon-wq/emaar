
export interface Property {
  id: string;
  title: string;
  location: string;
  image: string;
  description: string;
  category: 'Land' | 'Apartments' | 'Resort Share' | 'Hotel Share' | 'Land Share';
}

export interface Hotspot {
  id: string;
  top: string; // percentage
  left: string; // percentage
  title: string;
  description: string;
  specs?: { label: string; value: string }[];
}

export interface PropertyDetail {
  id: string;
  usps: string[];
  amenities: string[];
  blueprintDescription: string;
  blueprintImage: string;
  completionDate: string;
  virtualTourUrl?: string;
  virtualTourType?: 'video' | 'interactive' | '3d';
  hotspots?: Hotspot[];
}

export interface NavItem {
  label: string;
  href: string;
}

export interface JobOpening {
  id: string;
  title: string;
  department: string;
  location: string;
  description: string;
}

export type AppView = 'home' | 'portfolio' | 'careers' | 'contact';
