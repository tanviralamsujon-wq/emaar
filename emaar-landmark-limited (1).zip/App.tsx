
import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { VisionSection } from './components/VisionSection';
import { CategorySection } from './components/CategorySection';
import { PortfolioSlider } from './components/PortfolioSlider';
import { HeritageSection } from './components/HeritageSection';
import { Testimonials } from './components/Testimonials';
import { Footer } from './components/Footer';
import { EnquiryModal } from './components/EnquiryModal';
import { WhatsAppButton } from './components/WhatsAppButton';
import { PortfolioPage } from './components/PortfolioPage';
import { CareerPage } from './components/CareerPage';
import { ContactPage } from './components/ContactPage';
import { AnimatePresence, motion } from 'framer-motion';
import { AppView } from './types';

const App: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [isEnquiryOpen, setIsEnquiryOpen] = useState(false);
  const [view, setView] = useState<AppView>('home');

  useEffect(() => {
    const handleLoad = () => {
        setTimeout(() => setLoading(false), 2200);
    };

    if (document.readyState === 'complete') {
        handleLoad();
    } else {
        window.addEventListener('load', handleLoad);
        return () => window.removeEventListener('load', handleLoad);
    }
  }, []);

  const handleNavigate = (newView: AppView) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setView(newView);
  };

  const renderView = () => {
    switch (view) {
      case 'portfolio': return <PortfolioPage />;
      case 'careers': return <CareerPage />;
      case 'contact': return <ContactPage />;
      default: return (
        <>
          <Hero onNavigate={handleNavigate} />
          <VisionSection />
          <CategorySection />
          <PortfolioSlider />
          <HeritageSection />
          <Testimonials />
        </>
      );
    }
  };

  return (
    <div className="relative min-h-screen selection:bg-[#c5a059] selection:text-black bg-transparent">
      <AnimatePresence>
        {loading && (
          <motion.div
            key="loader"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, transition: { duration: 0.8, ease: "easeInOut" } }}
            className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-black"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="text-center"
            >
              <h1 className="text-4xl md:text-6xl font-serif tracking-widest text-[#c5a059] mb-2">EMAAR</h1>
              <p className="text-xs uppercase tracking-[0.5em] text-white/50">Landmark Limited</p>
            </motion.div>
            <motion.div 
              className="mt-12 w-48 h-[1px] bg-white/10 overflow-hidden"
              initial={{ width: 0 }}
              animate={{ width: 192 }}
            >
              <motion.div 
                className="h-full bg-[#c5a059]"
                initial={{ x: "-100%" }}
                animate={{ x: "100%" }}
                transition={{ repeat: Infinity, duration: 1.2, ease: "linear" }}
              />
            </motion.div>
            <motion.p 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                className="mt-6 text-[8px] uppercase tracking-[0.4em] text-white/20"
            >
                Architecting Prosperity
            </motion.p>
          </motion.div>
        )}
      </AnimatePresence>

      <Navbar 
        onEnquire={() => setIsEnquiryOpen(true)} 
        activeView={view} 
        onNavigate={handleNavigate} 
      />
      
      <main className={loading ? "opacity-0" : "opacity-100 transition-opacity duration-1000"}>
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.5 }}
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>

      <Footer onNavigate={handleNavigate} />

      <EnquiryModal isOpen={isEnquiryOpen} onClose={() => setIsEnquiryOpen(false)} />
      <WhatsAppButton />
    </div>
  );
};

export default App;
