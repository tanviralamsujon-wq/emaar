
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { GoogleGenAI } from "@google/genai";

const PROJECT_NODES = [
  { id: 'sec-01', top: '35%', left: '42%', title: 'Sector 01', type: 'Residential Hub' },
  { id: 'sec-02', top: '65%', left: '45%', title: 'Sector 02', type: 'Commercial Core' },
  { id: 'sec-03', top: '25%', left: '15%', title: 'Sector 03', type: 'Premium Estates' },
  { id: 'sec-04', top: '60%', left: '12%', title: 'Sector 04', type: 'Waterfront Living' },
  { id: 'nagori', top: '78%', left: '65%', title: 'Nagori Mission', type: 'Cultural Landmark' },
];

export const ProjectSpotlight: React.FC = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiRender, setAiRender] = useState<string | null>(null);
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);

  const generateVision = async () => {
    setIsGenerating(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-image-preview',
        contents: {
          parts: [{
            text: "A masterpiece architectural render of Lakeview City. Aerial view of 4 sectors of futuristic white luxury villas and apartments separated by a wide winding blue river with boats. Lush parks, 80ft wide boulevards with palm trees. Golden hour lighting, Nagori region aesthetic, photorealistic, 4k, hyper-luxury."
          }]
        },
        config: {
          imageConfig: {
            aspectRatio: "16:9",
            imageSize: "1K"
          }
        }
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          setAiRender(`data:image/png;base64,${part.inlineData.data}`);
          break;
        }
      }
    } catch (error) {
      console.error("AI Generation Error:", error);
      setAiRender("https://images.unsplash.com/photo-1449156001437-3a144f0083bb?auto=format&fit=crop&q=80&w=2000");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <section className="relative min-h-[120vh] bg-[#050505] py-32 overflow-hidden flex flex-col items-center">
      {/* Elegance Background: Massive Faded Title */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 pointer-events-none select-none">
        <h2 className="text-[15vw] font-serif italic text-white/[0.02] whitespace-nowrap leading-none">
          LAKEVIEW CITY
        </h2>
      </div>

      <div className="max-w-7xl w-full mx-auto px-6 relative z-10 flex flex-col">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
          <div className="max-w-xl">
            <motion.span 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              className="text-[#c5a059] uppercase tracking-[0.6em] text-[10px] mb-6 block font-bold"
            >
              The Masterplan
            </motion.span>
            <motion.h2 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-6xl md:text-8xl font-serif text-white mb-8"
            >
              Nagori's <span className="italic font-light luxury-gradient">New Dawn</span>
            </motion.h2>
          </div>
          
          <div className="flex flex-col items-end">
            <div className="flex gap-12 text-right mb-8">
               <div>
                  <p className="text-[#c5a059] text-2xl font-serif">04</p>
                  <p className="text-[8px] uppercase tracking-widest text-white/30">Strategic Sectors</p>
               </div>
               <div className="h-10 w-[1px] bg-white/10"></div>
               <div>
                  <p className="text-[#c5a059] text-2xl font-serif">80ft</p>
                  <p className="text-[8px] uppercase tracking-widest text-white/30">Arterial Avenues</p>
               </div>
            </div>
          </div>
        </div>

        {/* The Interactive Interactive Map Display */}
        <div className="relative aspect-[16/9] w-full bg-[#080808] border border-white/5 shadow-2xl overflow-hidden group">
          {/* Layout Image (The user's layout) */}
          <motion.div 
            initial={{ opacity: 0, scale: 1.05 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 2 }}
            className="absolute inset-0 p-12 md:p-24"
          >
             <img 
               src="https://raw.githubusercontent.com/username/repo/main/lakeview_layout.png" 
               alt="Lakeview Masterplan"
               className="w-full h-full object-contain brightness-110 contrast-125 filter drop-shadow-[0_0_30px_rgba(197,160,89,0.15)]"
               onError={(e) => {
                 (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&q=80&w=1200";
               }}
             />
          </motion.div>

          {/* Interactive Nodes HUD Layer */}
          <div className="absolute inset-0 pointer-events-none">
            {PROJECT_NODES.map((node) => (
              <div 
                key={node.id}
                className="absolute pointer-events-auto"
                style={{ top: node.top, left: node.left }}
                onMouseEnter={() => setHoveredNode(node.id)}
                onMouseLeave={() => setHoveredNode(null)}
              >
                <div className="relative flex items-center justify-center">
                  <motion.div 
                    animate={{ scale: [1, 2], opacity: [0.3, 0] }}
                    transition={{ repeat: Infinity, duration: 2.5 }}
                    className="absolute w-12 h-12 rounded-full border border-[#c5a059]/40"
                  />
                  <div className={`w-8 h-8 rounded-full border flex items-center justify-center transition-all duration-500 bg-black/60 backdrop-blur-md ${hoveredNode === node.id ? 'border-[#c5a059] scale-125' : 'border-white/10'}`}>
                    <div className="w-1.5 h-1.5 rounded-full bg-[#c5a059]"></div>
                  </div>
                  
                  <AnimatePresence>
                    {hoveredNode === node.id && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute bottom-12 whitespace-nowrap bg-black/80 backdrop-blur-xl border border-[#c5a059]/30 p-4 shadow-2xl"
                      >
                        <p className="text-[#c5a059] text-[9px] uppercase tracking-widest font-bold mb-1">{node.type}</p>
                        <p className="text-white text-xs font-serif italic">{node.title}</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            ))}
          </div>

          {/* Animated Scanning Line */}
          <motion.div 
            animate={{ top: ['-10%', '110%'] }}
            transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
            className="absolute left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#c5a059]/50 to-transparent z-10 pointer-events-none"
          />

          {/* Vision Portal Expansion (The Render) */}
          <AnimatePresence>
            {aiRender && (
              <motion.div 
                initial={{ clipPath: 'circle(0% at 90% 90%)' }}
                animate={{ clipPath: 'circle(150% at 90% 90%)' }}
                exit={{ clipPath: 'circle(0% at 90% 90%)' }}
                transition={{ duration: 1.5, ease: [0.77, 0, 0.175, 1] }}
                className="absolute inset-0 z-40 bg-black"
              >
                <img src={aiRender} className="w-full h-full object-cover scale-105" alt="Vision" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                <div className="absolute bottom-12 left-12">
                   <span className="text-[#c5a059] text-[10px] uppercase tracking-[0.5em] block mb-2 font-bold">Neural Visualization</span>
                   <h3 className="text-4xl font-serif text-white">The Living Reality</h3>
                </div>
                <button 
                  onClick={() => setAiRender(null)}
                  className="absolute top-12 right-12 w-12 h-12 rounded-full border border-white/20 flex items-center justify-center text-white hover:bg-white hover:text-black transition-all"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M18 6L6 18M6 6l12 12" />
                  </svg>
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* UI Controls Overlay */}
          <div className="absolute bottom-12 right-12 flex gap-4 z-30">
             <button 
               onClick={generateVision}
               disabled={isGenerating}
               className="group relative h-16 px-10 bg-black/60 backdrop-blur-xl border border-[#c5a059]/30 text-white overflow-hidden flex items-center gap-4 transition-all hover:border-[#c5a059]"
             >
               <div className="absolute inset-0 bg-[#c5a059] translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
               <span className="relative z-10 text-[10px] uppercase tracking-widest font-bold group-hover:text-black">
                 {isGenerating ? 'Synthesizing Vision...' : 'Visualize Future'}
               </span>
               {!isGenerating && (
                 <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" className="relative z-10 group-hover:text-black transition-colors">
                   <path d="M22 12l-4-4v8l4-4zM2 12l4 4V8l-4 4zM12 2l-4 4h8l-4-4zM12 22l4-4H8l4 4z" strokeWidth="1.5" />
                 </svg>
               )}
             </button>
          </div>

          <div className="absolute bottom-12 left-12 text-[10px] uppercase tracking-[0.4em] text-white/30 pointer-events-none">
             Nagori Region • Strategic Asset LL-04
          </div>
        </div>

        {/* Detailed Description Footer */}
        <div className="mt-24 grid md:grid-cols-3 gap-16 border-t border-white/5 pt-16">
           <div className="space-y-6">
              <h4 className="text-white text-lg font-serif italic">Waterfront Sanctuary</h4>
              <p className="text-white/40 text-[11px] leading-relaxed uppercase tracking-widest font-light">
                Every sector is anchored by a central artery of water, inviting tranquility into the urban fabric and providing a unique transport modality.
              </p>
           </div>
           <div className="space-y-6">
              <h4 className="text-white text-lg font-serif italic">Infrastructural Might</h4>
              <p className="text-white/40 text-[11px] leading-relaxed uppercase tracking-widest font-light">
                Spanning 80ft wide boulevards, Lakeview City ensures seamless mobility and represents the architectural pinnacle of Nagori's development.
              </p>
           </div>
           <div className="space-y-6">
              <h4 className="text-white text-lg font-serif italic">Bespoke Heritage</h4>
              <p className="text-white/40 text-[11px] leading-relaxed uppercase tracking-widest font-light">
                Integrating closely with the Nagori Christian Mission, the development respects cultural heritage while pioneering futuristic lifestyle standards.
              </p>
           </div>
        </div>
      </div>
    </section>
  );
};
