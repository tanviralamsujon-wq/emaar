
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Property } from '../types';

interface ShareModalProps {
  property: Property | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ property, isOpen, onClose }) => {
  if (!property) return null;

  const shareUrl = window.location.href; // In a real app, this might be a specific property link
  const shareText = `Check out this incredible landmark: ${property.title} by Emaar Landmark Limited.`;

  const shareOptions = [
    {
      name: 'WhatsApp',
      icon: (
        <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
          <path d="M12.031 2c-5.516 0-9.969 4.453-9.969 9.969 0 1.765.461 3.422 1.265 4.875l-1.344 4.906 5.031-1.328c1.422.766 3.031 1.203 4.734 1.203 5.516 0 10.031-4.453 10.031-10.031-.016-5.516-4.5-9.969-10.063-9.969-.031 0-.031 0 0 0zm0 1.5c4.688 0 8.5 3.813 8.5 8.5s-3.813 8.5-8.5 8.5c-1.641 0-3.172-.469-4.484-1.281l-.328-.188-2.984.781.813-2.922-.219-.344c-.813-1.313-1.25-2.844-1.25-4.438.016-4.688 3.828-8.516 8.453-8.609h.5z" />
        </svg>
      ),
      color: '#25D366',
      link: `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`,
    },
    {
      name: 'LinkedIn',
      icon: (
        <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
          <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a2.7 2.7 0 0 0-2.7-2.7c-1.2 0-2.1.7-2.5 1.4v-1.1h-2.5v7.7h2.5v-4.1c0-.7.6-1.3 1.3-1.3s1.3.6 1.3 1.3v4.1h2.6m-11.4-8.8h2.6v7.7H7.1v-7.7m1.3-3a1.3 1.3 0 1 0 0 2.6 1.3 1.3 0 0 0 0-2.6z" />
        </svg>
      ),
      color: '#0077B5',
      link: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`,
    },
    {
      name: 'X / Twitter',
      icon: (
        <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231 5.45-6.231zm-1.161 17.52h1.833L7.084 4.126H5.117L17.083 19.77z" />
        </svg>
      ),
      color: '#ffffff',
      link: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`,
    },
    {
      name: 'Email',
      icon: (
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
          <polyline points="22,6 12,13 2,6" />
        </svg>
      ),
      color: '#c5a059',
      link: `mailto:?subject=${encodeURIComponent('Legendary Living: ' + property.title)}&body=${encodeURIComponent(shareText + '\n\n' + shareUrl)}`,
    },
  ];

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareUrl);
    alert('Link copied to clipboard');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-[120] bg-black/90 backdrop-blur-xl"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed inset-0 z-[121] flex items-center justify-center p-6 pointer-events-none"
          >
            <div className="bg-[#0a0a0a] border border-[#c5a059]/30 w-full max-w-md p-10 relative pointer-events-auto shadow-[0_30px_100px_rgba(0,0,0,1)]">
              <button 
                onClick={onClose}
                className="absolute top-6 right-6 text-white/40 hover:text-[#c5a059] transition-colors"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 6L6 18M6 6l12 12" />
                </svg>
              </button>

              <div className="text-center mb-10">
                <span className="text-[#c5a059] uppercase tracking-[0.4em] text-[10px] mb-4 block">Share Excellence</span>
                <h2 className="text-3xl font-serif text-white mb-2">{property.title}</h2>
                <p className="text-white/40 text-[10px] uppercase tracking-widest">{property.location}</p>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-10">
                {shareOptions.map((option) => (
                  <a
                    key={option.name}
                    href={option.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex flex-col items-center justify-center p-6 border border-white/5 bg-white/[0.02] hover:border-[#c5a059]/40 hover:bg-white/[0.05] transition-all group"
                  >
                    <div className="mb-3 transition-transform group-hover:scale-110" style={{ color: option.color }}>
                      {option.icon}
                    </div>
                    <span className="text-[9px] uppercase tracking-widest text-white/60 group-hover:text-white">
                      {option.name}
                    </span>
                  </a>
                ))}
              </div>

              <div className="relative">
                <input 
                  type="text" 
                  readOnly 
                  value={shareUrl} 
                  className="w-full bg-black border border-white/10 p-4 pr-32 text-[10px] text-white/40 outline-none font-mono tracking-tighter"
                />
                <button 
                  onClick={copyToClipboard}
                  className="absolute right-2 top-2 bottom-2 bg-[#c5a059] text-black px-6 text-[9px] uppercase tracking-widest font-bold hover:bg-white transition-colors"
                >
                  Copy Link
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
