
import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

export const VisionSection: React.FC = () => {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const imgY = useTransform(scrollYProgress, [0, 1], ["-12%", "12%"]);
  const textY = useTransform(scrollYProgress, [0, 1], ["8%", "-8%"]);
  
  const emaarDeconstruction = [
    { root: 'E', meaning: 'Excellence in every foundation we lay.' },
    { root: 'M', meaning: 'Mastery over architectural innovation.' },
    { root: 'A', meaning: 'Ambition to redefine global skylines.' },
    { root: 'A', meaning: 'Artistry in the balance of form and function.' },
    { root: 'R', meaning: 'Resilience in crafting enduring legacies.' }
  ];

  const subtitle = "Rooted in Flourishing";
  const subtitleChars = Array.from(subtitle);

  return (
    <section id="vision" ref={containerRef} className="relative py-24 md:py-48 px-6 bg-transparent overflow-hidden section-reveal">
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-black via-transparent to-black"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black via-transparent to-black"></div>
      </div>

      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-24 items-center relative z-10">
        <motion.div
          style={{ y: imgY }}
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
          className="relative group will-animate"
        >
          <div className="absolute -inset-8 border border-[#c5a059]/10 group-hover:border-[#c5a059]/30 transition-all duration-1000"></div>
          <div className="absolute top-0 left-0 w-20 h-20 border-t-2 border-l-2 border-[#c5a059] -translate-x-4 -translate-y-4"></div>
          
          <div className="overflow-hidden bg-[#0a0a0a] shadow-[0_50px_100px_rgba(0,0,0,0.8)]">
            <img 
              loading="lazy"
              src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1200" 
              alt="Emaar Architecture" 
              className="w-full h-auto grayscale group-hover:grayscale-0 transition-all duration-[2s] scale-110 group-hover:scale-105"
            />
          </div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.8, duration: 1 }}
            className="absolute -bottom-12 -right-12 bg-black/80 backdrop-blur-3xl p-10 border border-[#c5a059]/40 max-w-sm hidden lg:block"
          >
            <span className="text-[#c5a059] text-[9px] uppercase tracking-[0.5em] mb-4 block">The Core Philosophy</span>
            <p className="text-white font-serif text-2xl italic leading-tight">
              "We don't build projects; we cultivate environments where prosperity takes root."
            </p>
          </motion.div>
        </motion.div>

        <motion.div
          style={{ y: textY }}
          className="will-animate"
        >
          <div className="overflow-hidden mb-8">
            <motion.div className="flex">
              {subtitleChars.map((char, i) => (
                <motion.span
                  key={i}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2 + (i * 0.03), duration: 0.3 }}
                  className="text-[#c5a059] uppercase tracking-[0.6em] text-[10px] md:text-xs font-bold inline-block whitespace-pre"
                >
                  {char}
                </motion.span>
              ))}
            </motion.div>
          </div>

          <div className="overflow-hidden mb-12">
            <motion.h2 
              initial={{ y: "100%", color: "rgba(255,255,255,0.15)" }}
              whileInView={{ y: 0, color: "rgba(255,255,255,1)" }}
              viewport={{ once: true }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="text-6xl md:text-8xl font-serif leading-none"
            >
              The Meaning of <br /> <span className="luxury-gradient italic">Emaar</span>
            </motion.h2>
          </div>
          
          <div className="space-y-8 mb-16">
            {emaarDeconstruction.map((item, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.15 }}
                className="flex items-center gap-8 group/item"
              >
                <span className="text-4xl md:text-5xl font-serif text-[#c5a059]/20 group-hover/item:text-[#c5a059] transition-all duration-500">{item.root}</span>
                <div className="h-[1px] w-8 bg-white/10 group-hover/item:w-16 group-hover/item:bg-[#c5a059]/40 transition-all duration-500"></div>
                <p className="text-white/60 text-sm md:text-base font-light tracking-wide group-hover/item:text-white transition-colors">
                  {item.meaning}
                </p>
              </motion.div>
            ))}
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="space-y-6 text-white/50 text-lg leading-relaxed font-light font-sans mb-12"
          >
            <p>
              In the Arabic language, <span className="text-white font-serif italic text-xl">"Emaar"</span> (عمار) carries the weight of a sacred promise: to construct, to settle, and to make a place thrive for generations. 
            </p>
            <p>
              At Emaar Landmark Limited, we honor this etymology by ensuring every landmark we engineer serves as a catalyst for urban prosperity and architectural delight.
            </p>
          </motion.div>

          <div className="flex flex-col sm:flex-row gap-8 pt-8">
            <button 
              onClick={() => {
                const heritage = document.getElementById('heritage');
                heritage?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="group flex items-center gap-6 text-[#c5a059] uppercase tracking-[0.4em] text-xs font-bold hover:text-white transition-all duration-500"
            >
              Explore Our Ethos
              <div className="relative w-16 h-[1px] bg-white/20 overflow-hidden">
                <div className="absolute inset-0 bg-[#c5a059] -translate-x-full group-hover:translate-x-0 transition-transform duration-700"></div>
              </div>
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
