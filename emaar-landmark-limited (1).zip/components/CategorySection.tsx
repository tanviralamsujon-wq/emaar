
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const categories = [
  {
    title: 'Land',
    subtitle: 'Eternal Foundations',
    description: 'Acquire premium, strategically located land plots designed for multi-generational wealth and bespoke architectural freedom.',
    image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&q=80&w=1000',
    stats: '150+ ACRES'
  },
  {
    title: 'Apartments',
    subtitle: 'Sky Sanctuaries',
    description: 'Bespoke high-rise living spaces designed for those who seek ultimate privacy and unparalleled urban vistas.',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1000',
    stats: '12 DEVELOPMENTS'
  },
  {
    title: 'Resort Share',
    subtitle: 'Global Retreats',
    description: 'Fractional ownership in world-class vacation destinations, blending high-end leisure with intelligent asset management.',
    image: 'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&q=80&w=1000',
    stats: '5 DESTINATIONS'
  },
  {
    title: 'Hotel Share',
    subtitle: 'Hospitality Assets',
    description: 'Invest in the thriving global hospitality sector with managed hotel units that offer consistent returns and lifestyle perks.',
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=1000',
    stats: '8 LANDMARKS'
  },
  {
    title: 'Land Share',
    subtitle: 'Collective Prosperity',
    description: 'Innovative co-ownership models for large-scale land development projects, lowering barriers to premium real estate.',
    image: 'https://images.unsplash.com/photo-1449156001437-3a144f0083bb?auto=format&fit=crop&q=80&w=1000',
    stats: '22 COMMUNITIES'
  }
];

export const CategorySection: React.FC = () => {
  const [activeSlide, setActiveSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % categories.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const subtitle = "Our Offerings";
  const subtitleChars = Array.from(subtitle);

  return (
    <section className="py-32 bg-transparent overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <header className="mb-20 text-center md:text-left">
          <div className="overflow-hidden mb-4">
            <motion.div className="flex justify-center md:justify-start">
               {subtitleChars.map((char, i) => (
                 <motion.span
                   key={i}
                   initial={{ opacity: 0 }}
                   whileInView={{ opacity: 1 }}
                   viewport={{ once: true }}
                   transition={{ delay: 0.1 + (i * 0.03), duration: 0.3 }}
                   className="text-[#c5a059] uppercase tracking-[0.6em] text-[10px] font-bold inline-block whitespace-pre"
                 >
                   {char}
                 </motion.span>
               ))}
             </motion.div>
          </div>
          
          <div className="overflow-hidden">
            <motion.h2 
              initial={{ y: "100%", color: "rgba(255,255,255,0.15)" }}
              whileInView={{ y: 0, color: "rgba(255,255,255,1)" }}
              viewport={{ once: true }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="text-5xl md:text-7xl font-serif text-white mb-6"
            >
              Diverse <span className="italic font-light luxury-gradient">Dimensions</span>
            </motion.h2>
          </div>
          
          <motion.div 
            initial={{ width: 0 }}
            whileInView={{ width: 100 }}
            viewport={{ once: true }}
            transition={{ duration: 1.5, delay: 0.5 }}
            className="h-[1px] bg-[#c5a059] mb-8"
          />
        </header>

        <div className="flex flex-col gap-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 relative">
            {categories.map((cat, i) => (
              <motion.div
                key={cat.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`group relative h-[500px] overflow-hidden cursor-pointer transition-all duration-1000 ${
                  activeSlide === i ? 'ring-2 ring-[#c5a059]/40 z-20 scale-105 shadow-[0_0_50px_rgba(197,160,89,0.2)]' : 'opacity-40 hover:opacity-100'
                }`}
                onClick={() => setActiveSlide(i)}
              >
                <img 
                  src={cat.image} 
                  alt={cat.title} 
                  className={`absolute inset-0 w-full h-full object-cover grayscale transition-all duration-[2s] ease-out ${
                    activeSlide === i ? 'grayscale-0 scale-110 brightness-75' : 'brightness-50'
                  }`}
                />
                
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"></div>
                <div className={`absolute inset-0 border transition-all duration-1000 m-4 ${
                  activeSlide === i ? 'border-[#c5a059]/50' : 'border-white/5'
                }`}></div>
                
                <div className={`absolute top-0 left-0 right-0 h-[2px] bg-[#c5a059]/40 z-10 pointer-events-none ${
                  activeSlide === i ? 'animate-scan' : ''
                }`}></div>

                <div className="absolute inset-0 p-8 flex flex-col justify-end">
                  <span className="text-[9px] text-[#c5a059] tracking-[0.4em] uppercase mb-3 block font-bold">
                    {cat.subtitle}
                  </span>
                  <h3 className={`text-2xl font-serif text-white mb-4 transition-colors ${
                    activeSlide === i ? 'text-[#c5a059]' : ''
                  }`}>
                    {cat.title}
                  </h3>
                  
                  <div className={`transition-all duration-700 ease-in-out overflow-hidden ${
                    activeSlide === i ? 'max-h-32 opacity-100' : 'max-h-0 opacity-0'
                  }`}>
                    <p className="text-white/60 text-[11px] font-light leading-relaxed mb-6">
                      {cat.description}
                    </p>
                  </div>

                  <div className="mt-4 flex justify-between items-center border-t border-white/10 pt-4">
                    <span className="text-[8px] text-white/40 tracking-widest uppercase">{cat.stats}</span>
                    <div className={`w-8 h-8 rounded-full border border-[#c5a059]/30 flex items-center justify-center transition-all ${
                      activeSlide === i ? 'bg-[#c5a059] text-black' : ''
                    }`}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                        <path d="M5 12h14M12 5l7 7-7 7" />
                      </svg>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="flex justify-center gap-4 mt-8">
            {categories.map((_, i) => (
              <button
                key={i}
                onClick={() => setActiveSlide(i)}
                className={`h-1 transition-all duration-500 rounded-full ${activeSlide === i ? 'w-12 bg-[#c5a059]' : 'w-4 bg-white/10 hover:bg-white/30'}`}
              />
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes scan {
          0% { top: 0%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
        .animate-scan {
          animation: scan 3s linear infinite;
        }
      `}</style>
    </section>
  );
};
