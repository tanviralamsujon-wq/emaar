
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import emailjs from '@emailjs/browser';

export const ContactPage: React.FC = () => {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', project: '', message: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSending(true);

    try {
      await emailjs.send(
        'service_2lgls4m',
        'template_lygyfab',
        {
          from_name: formData.name,
          reply_to: formData.email,
          project_interest: formData.project,
          message: formData.message,
          to_name: 'Emaar Sales Team'
        },
        'pwFViAXObrEFNBJdV'
      );

      setFormSubmitted(true);
      setFormData({ name: '', email: '', project: '', message: '' });
      setTimeout(() => setFormSubmitted(false), 5000);
    } catch (error) {
      console.error('Contact Form Error:', error);
      alert('Transmission failed. Please check your network.');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="pt-32 pb-24 bg-[#050505] min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-24">
          {/* Form Side */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <span className="text-[#c5a059] uppercase tracking-[0.5em] text-[10px] mb-4 block">Get in Touch</span>
            <h1 className="text-6xl md:text-8xl font-serif text-white mb-12">Direct <br /><span className="italic font-light">Dialogue</span></h1>
            
            <AnimatePresence mode="wait">
              {formSubmitted ? (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="bg-[#c5a059]/5 border border-[#c5a059]/20 p-12 text-center"
                >
                  <h3 className="text-3xl font-serif text-[#c5a059] mb-4">Message Encoded</h3>
                  <p className="text-white/40 uppercase tracking-widest text-[10px]">A specialist will contact you momentarily.</p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-8">
                  <div className="grid md:grid-cols-2 gap-8">
                    <input 
                      type="text" 
                      placeholder="NAME" 
                      required 
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      disabled={isSending}
                      className="w-full bg-transparent border-b border-white/10 py-4 text-[11px] tracking-widest text-white uppercase focus:border-[#c5a059] outline-none transition-colors" 
                    />
                    <input 
                      type="email" 
                      placeholder="EMAIL" 
                      required 
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      disabled={isSending}
                      className="w-full bg-transparent border-b border-white/10 py-4 text-[11px] tracking-widest text-white uppercase focus:border-[#c5a059] outline-none transition-colors" 
                    />
                  </div>
                  <input 
                    type="text" 
                    placeholder="INTERESTED PROJECT" 
                    value={formData.project}
                    onChange={(e) => setFormData({...formData, project: e.target.value})}
                    disabled={isSending}
                    className="w-full bg-transparent border-b border-white/10 py-4 text-[11px] tracking-widest text-white uppercase focus:border-[#c5a059] outline-none transition-colors" 
                  />
                  <textarea 
                    placeholder="MESSAGE" 
                    rows={4} 
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    disabled={isSending}
                    className="w-full bg-transparent border-b border-white/10 py-4 text-[11px] tracking-widest text-white uppercase focus:border-[#c5a059] outline-none transition-colors resize-none" 
                  />
                  <button 
                    disabled={isSending}
                    className="w-full py-5 bg-[#c5a059] text-black text-[10px] font-bold uppercase tracking-[0.4em] hover:bg-white transition-all duration-500 flex items-center justify-center gap-4"
                  >
                    {isSending ? (
                      <>
                        <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }} className="w-4 h-4 border border-black border-t-transparent rounded-full" />
                        <span>Sending Transmission...</span>
                      </>
                    ) : 'Secure Transmission'}
                  </button>
                </form>
              )}
            </AnimatePresence>

            <div className="mt-20 grid grid-cols-2 gap-12">
               <div>
                  <h4 className="text-[10px] uppercase tracking-widest text-[#c5a059] mb-4">Headquarters</h4>
                  <p className="text-white/40 text-xs leading-relaxed uppercase tracking-widest">
                    House: 171, Road: 03<br />Mohakhali DOHS<br />Dhaka - 1206, Bangladesh
                  </p>
               </div>
               <div>
                  <h4 className="text-[10px] uppercase tracking-widest text-[#c5a059] mb-4">Private Line</h4>
                  <p className="text-white/40 text-xs leading-relaxed uppercase tracking-widest">
                    +880 1713 677 154<br />info@emaarlandmark.com
                  </p>
               </div>
            </div>
          </motion.div>

          {/* Map Side */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative h-[600px] lg:h-auto bg-white/5 overflow-hidden group border border-white/10"
          >
            {/* Overlay UI */}
            <div className="absolute inset-0 pointer-events-none z-10">
               <div className="absolute top-8 right-8 bg-black/80 backdrop-blur-md p-6 border border-[#c5a059]/30">
                  <span className="text-[10px] uppercase tracking-widest text-[#c5a059] block mb-2">Live Node</span>
                  <div className="flex items-center gap-3">
                     <div className="w-2 h-2 rounded-full bg-[#c5a059] animate-pulse"></div>
                     <p className="text-white text-[9px] uppercase tracking-widest">23.7779° N, 90.3944° E</p>
                  </div>
               </div>
            </div>

            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.1444645224354!2d90.39294277590216!3d23.777856487739527!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c76da35176af%3A0x6b7729f2122607e4!2sMohakhali%20DOHS%2C%20Dhaka!5e0!3m2!1sen!2sbd!4v1710000000000!5m2!1sen!2sbd"
              className="w-full h-full grayscale invert opacity-50 contrast-125"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </motion.div>
        </div>
      </div>
    </div>
  );
};
