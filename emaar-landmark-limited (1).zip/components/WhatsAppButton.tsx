
import React from 'react';
import { motion } from 'framer-motion';

export const WhatsAppButton: React.FC = () => {
  return (
    <motion.a
      href="https://wa.me/8801713677154"
      target="_blank"
      rel="noopener noreferrer"
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      className="fixed bottom-10 right-10 z-50 group"
    >
      <div className="absolute inset-0 bg-gradient-to-tr from-[#c5a059] to-[#25D366] rounded-full blur-lg opacity-40 group-hover:opacity-100 transition-opacity duration-500"></div>
      <div className="relative w-16 h-16 bg-[#0a0a0a] border border-[#c5a059] rounded-full flex items-center justify-center shadow-2xl overflow-hidden">
        <i className="fa-brands fa-whatsapp text-3xl text-[#c5a059] group-hover:text-[#25D366] transition-colors duration-300"></i>
      </div>
      <div className="absolute right-20 top-1/2 -translate-y-1/2 bg-black/80 backdrop-blur-md border border-[#c5a059]/20 px-4 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
        <span className="text-[#c5a059] text-[10px] uppercase tracking-widest">Connect on WhatsApp</span>
      </div>
    </motion.a>
  );
};
