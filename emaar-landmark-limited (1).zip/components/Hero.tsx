
import React, { useRef, useState, useEffect } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { AppView } from '../types';

interface HeroProps {
  onNavigate: (view: AppView) => void;
}

const HERO_SLIDES = [
  { type: 'video', url: 'https://assets.mixkit.co/videos/preview/mixkit-modern-city-skyscrapers-and-buildings-at-night-42512-large.mp4' },
  { type: 'image', url: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80&w=2000' },
  { type: 'image', url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=2000' },
  { type: 'video', url: 'https://assets.mixkit.co/videos/preview/mixkit-high-angle-view-of-a-city-at-night-42511-large.mp4' }
];

export const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  const ref = useRef(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"]
  });

  const videoY = useTransform(scrollYProgress, [0, 1], ["0%", "20%"]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "40%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  const subtitleText = "The Principle of Heritage";
  const subtitleChars = Array.from(subtitleText);

  return (
    <section ref={ref} className="relative h-screen w-full overflow-hidden bg-black">
      <motion.div 
        style={{ y: videoY }}
        className="absolute inset-0 z-0 will-animate"
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 2.5, ease: [0.16, 1, 0.3, 1] }}
            className="absolute inset-0 w-full h-full"
          >
            {HERO_SLIDES[currentSlide].type === 'video' ? (
              <video
                autoPlay
                loop
                muted
                playsInline
                className="w-full h-full object-cover brightness-[0.4]"
              >
                <source src={HERO_SLIDES[currentSlide].url} type="video/mp4" />
              </video>
            ) : (
              <img 
                src={HERO_SLIDES[currentSlide].url} 
                className="w-full h-full object-cover brightness-[0.4]"
                alt="Emaar Luxury"
              />
            )}
          </motion.div>
        </AnimatePresence>
        <div className="absolute inset-0 bg-black/30 backdrop-blur-[1px]"></div>
      </motion.div>

      <motion.div 
        style={{ y: textY, opacity }}
        className="relative z-10 h-full flex flex-col justify-center items-center text-center px-6 pt-52 md:pt-32 will-animate"
      >
        <motion.div className="mb-16">
          <div className="overflow-hidden mb-8">
            <motion.div className="flex justify-center flex-wrap">
              {subtitleChars.map((char, i) => (
                <motion.span
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + (i * 0.03), duration: 0.5 }}
                  className="text-[#c5a059] uppercase tracking-[0.2em] md:tracking-[0.8em] text-[10px] md:text-xs font-sans font-bold inline-block whitespace-pre"
                >
                  {char}
                </motion.span>
              ))}
            </motion.div>
          </div>

          <div className="overflow-hidden">
            <motion.h1 
              initial={{ y: "100%", color: "rgba(255,255,255,0.15)" }}
              animate={{ y: 0, color: "rgba(255,255,255,1)" }}
              transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1], delay: 0.3 }}
              className="text-6xl md:text-8xl lg:text-[10rem] font-serif leading-[0.85] tracking-tight"
            >
              The Art of <br />
              <span className="italic font-light luxury-gradient">Prosperity</span>
            </motion.h1>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.2 }}
          className="flex flex-col items-center gap-16 w-full max-w-2xl"
        >
          <div className="flex flex-col sm:flex-row items-center justify-center gap-8 w-full">
            <button 
              onClick={() => onNavigate('portfolio')}
              className="group relative w-full sm:w-64 py-5 border border-[#c5a059] overflow-hidden transition-all duration-500"
            >
              <div className="absolute inset-0 bg-[#c5a059] translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-[0.16,1,0.3,1]"></div>
              <span className="relative z-10 text-[#c5a059] group-hover:text-black text-[11px] uppercase tracking-[0.4em] font-bold transition-colors duration-500 font-sans">
                Buy Property
              </span>
            </button>

            <button 
              onClick={() => onNavigate('contact')}
              className="group relative w-full sm:w-64 py-5 border border-white overflow-hidden transition-all duration-500"
            >
              <div className="absolute inset-0 bg-white translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-[0.16,1,0.3,1]"></div>
              <span className="relative z-10 text-white group-hover:text-black text-[11px] uppercase tracking-[0.4em] font-bold transition-colors duration-500 font-sans">
                Sell Property
              </span>
            </button>
          </div>
          
          <motion.div 
            animate={{ y: [0, 10, 0], opacity: [0.2, 0.4, 0.2] }}
            transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
            className="flex flex-col items-center gap-4"
          >
            <span className="text-[9px] uppercase tracking-[0.5em] text-white/30 font-sans">Scroll to explore</span>
            <div className="w-[1px] h-24 bg-gradient-to-b from-[#c5a059] to-transparent"></div>
          </motion.div>
        </motion.div>
      </motion.div>

      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-20 flex gap-3">
        {HERO_SLIDES.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentSlide(i)}
            className="group relative h-1 overflow-hidden transition-all duration-500"
            style={{ width: currentSlide === i ? '40px' : '12px' }}
          >
            <div className={`absolute inset-0 transition-colors duration-500 ${currentSlide === i ? 'bg-[#c5a059]' : 'bg-white/20 hover:bg-white/40'}`}></div>
          </button>
        ))}
      </div>
    </section>
  );
};
