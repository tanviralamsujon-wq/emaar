
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { NAV_ITEMS } from '../constants';
import { AppView } from '../types';

interface NavbarProps {
  onEnquire?: () => void;
  activeView: AppView;
  onNavigate: (view: AppView) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onEnquire, activeView, onNavigate }) => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${
        scrolled || activeView !== 'home' ? 'glass-nav py-3' : 'bg-transparent py-8'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        {/* Brand Identity */}
        <div 
          className="flex flex-col cursor-pointer group" 
          onClick={() => onNavigate('home')}
        >
          <span className="text-2xl md:text-3xl font-serif font-bold tracking-tight text-[#c5a059] group-hover:brightness-125 transition-all duration-700">EMAAR</span>
          <span className="text-[10px] uppercase tracking-[0.3em] text-white/50 -mt-1 font-sans group-hover:text-white transition-colors duration-500">Landmark Limited</span>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden lg:flex gap-10 items-center">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.label}
              onClick={() => onNavigate(item.href as AppView)}
              className={`text-[10px] uppercase tracking-[0.3em] transition-all relative group font-sans font-medium ${
                activeView === item.href ? 'text-[#c5a059]' : 'text-white/60 hover:text-[#c5a059]'
              }`}
            >
              {item.label}
              <span className={`absolute -bottom-1 left-0 h-[1px] bg-[#c5a059] transition-all duration-500 ${
                activeView === item.href ? 'w-full' : 'w-0 group-hover:w-full'
              }`}></span>
            </button>
          ))}
          
          <div className="h-6 w-[1px] bg-white/10 mx-2"></div>
          
          {/* Enhanced Luxury Hotline - Fixed with Direct Call Link */}
          <motion.a 
            href="tel:+8801713677154" 
            whileHover={{ scale: 1.05 }}
            className="flex items-center gap-4 group relative px-4 py-2 rounded-full transition-all duration-500"
          >
            <div className="relative">
              <motion.div 
                animate={{ scale: [1, 1.5, 1], opacity: [0.4, 0, 0.4] }}
                transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut" }}
                className="absolute inset-0 rounded-full bg-[#c5a059]/20"
              />
              <div className="w-10 h-10 rounded-full border border-[#c5a059]/40 flex items-center justify-center group-hover:border-[#c5a059] group-hover:bg-[#c5a059]/10 transition-all duration-500 bg-black/40 backdrop-blur-sm relative z-10">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#c5a059" strokeWidth="2" className="relative z-10">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                </svg>
              </div>
            </div>

            <div className="flex flex-col relative z-10">
              <span className="text-[7px] uppercase tracking-[0.4em] text-white/40 font-sans font-medium group-hover:text-[#c5a059]/60 transition-colors duration-500">HotLine</span>
              <span className="text-[11px] uppercase tracking-[0.2em] text-white group-hover:text-[#c5a059] transition-colors duration-500 font-bold font-sans">+8801713677154</span>
            </div>
          </motion.a>
        </div>

        {/* Global Action CTA */}
        <button 
          onClick={onEnquire}
          className="relative px-7 py-2.5 border border-[#c5a059] text-[#c5a059] text-[10px] uppercase tracking-widest overflow-hidden group/btn font-bold font-sans transition-all duration-500"
        >
          <div className="absolute inset-0 bg-[#c5a059] translate-y-full group-hover/btn:translate-y-0 transition-transform duration-500 ease-out"></div>
          <span className="relative z-10 group-hover/btn:text-black transition-colors duration-500">Enquire</span>
        </button>
      </div>
    </motion.nav>
  );
};
