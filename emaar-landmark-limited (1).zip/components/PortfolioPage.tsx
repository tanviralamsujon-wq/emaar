
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PROPERTIES, PROPERTY_DETAILS } from '../constants';
import { PropertyDetailModal } from './PropertyDetailModal';
import { ShareModal } from './ShareModal';
import { Property } from '../types';

export const PortfolioPage: React.FC = () => {
  const [filter, setFilter] = useState<'All' | 'Land' | 'Apartments' | 'Resort Share' | 'Hotel Share' | 'Land Share'>('All');
  const [selectedPropertyId, setSelectedPropertyId] = useState<string | null>(null);
  const [sharingProperty, setSharingProperty] = useState<Property | null>(null);

  const filteredProperties = filter === 'All' 
    ? PROPERTIES 
    : PROPERTIES.filter(p => p.category === filter);

  const selectedProperty = PROPERTIES.find(p => p.id === selectedPropertyId) || null;
  const selectedDetails = selectedProperty ? PROPERTY_DETAILS[selectedProperty.id] : null;

  const handleShareClick = (e: React.MouseEvent, property: Property) => {
    e.stopPropagation();
    setSharingProperty(property);
  };

  return (
    <div className="pt-32 pb-24 bg-[#050505] min-h-screen font-sans">
      <div className="max-w-7xl mx-auto px-6">
        <header className="mb-20">
          <span className="text-[#c5a059] uppercase tracking-[0.5em] text-[10px] mb-4 block">Our Portfolio</span>
          <h1 className="text-6xl md:text-8xl font-serif text-white mb-8">Architectural <br /><span className="italic font-light">Excellence</span></h1>
          
          <div className="flex flex-wrap gap-8 border-b border-white/5 pb-8 overflow-x-auto no-scrollbar">
            {['All', 'Land', 'Apartments', 'Resort Share', 'Hotel Share', 'Land Share'].map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat as any)}
                className={`text-[10px] uppercase tracking-[0.3em] transition-all relative whitespace-nowrap py-2 ${filter === cat ? 'text-[#c5a059] font-bold' : 'text-white/40 hover:text-white'}`}
              >
                {cat}
                {filter === cat && (
                  <motion.div layoutId="underline" className="absolute -bottom-8 left-0 right-0 h-[2px] bg-[#c5a059]" />
                )}
              </button>
            ))}
          </div>
        </header>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12">
          <AnimatePresence mode="popLayout">
            {filteredProperties.map((property) => (
              <motion.div
                key={property.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="group cursor-pointer"
                onClick={() => setSelectedPropertyId(property.id)}
              >
                <div className="relative aspect-[4/5] overflow-hidden bg-white/5 mb-6">
                  <img 
                    src={property.image} 
                    alt={property.title} 
                    className="w-full h-full object-cover grayscale brightness-75 group-hover:grayscale-0 group-hover:scale-110 group-hover:brightness-100 transition-all duration-1000"
                  />
                  <div className="absolute inset-0 border border-white/10 group-hover:border-[#c5a059]/40 transition-all duration-500 m-4"></div>
                  
                  {/* Floating Action Hint */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
                     <div className="bg-black/60 backdrop-blur-md border border-[#c5a059]/30 px-6 py-3 text-[10px] uppercase tracking-widest text-white translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                        View Landmark
                     </div>
                  </div>
                </div>

                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <span className="text-[9px] uppercase tracking-widest text-[#c5a059] mb-2 block font-bold">{property.category}</span>
                    <h3 className="text-2xl font-serif text-white group-hover:text-[#c5a059] transition-colors">{property.title}</h3>
                    <p className="text-[10px] uppercase tracking-widest text-white/30 mt-1 font-light">{property.location}</p>
                  </div>
                  <div className="flex gap-2">
                    {/* Share Button */}
                    <button 
                      onClick={(e) => handleShareClick(e, property)}
                      className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-white/40 hover:border-[#c5a059] hover:text-[#c5a059] transition-all bg-white/5 hover:bg-black"
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="18" cy="5" r="3" />
                        <circle cx="6" cy="12" r="3" />
                        <circle cx="18" cy="19" r="3" />
                        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" />
                        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" />
                      </svg>
                    </button>
                    {/* View Details Button */}
                    <div className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center group-hover:border-[#c5a059] group-hover:bg-[#c5a059] transition-all bg-white/5">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" className="group-hover:text-black">
                        <path d="M7 17l9.2-9.2M17 17V7H7" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      <PropertyDetailModal 
        isOpen={!!selectedPropertyId} 
        onClose={() => setSelectedPropertyId(null)}
        property={selectedProperty}
        details={selectedDetails}
      />

      <ShareModal 
        property={sharingProperty} 
        isOpen={!!sharingProperty} 
        onClose={() => setSharingProperty(null)} 
      />
    </div>
  );
};
