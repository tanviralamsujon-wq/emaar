
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import emailjs from '@emailjs/browser';

interface EnquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EnquiryModal: React.FC<EnquiryModalProps> = ({ isOpen, onClose }) => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSending, setIsSending] = useState(false);

  const validateEmail = (email: string) => {
    return String(email)
      .toLowerCase()
      .match(
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: { [key: string]: string } = {};

    if (!formState.name.trim()) newErrors.name = 'Name is required';
    if (!formState.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!validateEmail(formState.email)) {
      newErrors.email = 'Valid email required';
    }
    if (!formState.message.trim()) newErrors.message = 'Message is required';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsSending(true);

    try {
      // Replace with your actual EmailJS credentials
      await emailjs.send(
        'service_2lgls4m', 
        'template_lygyfab', 
        {
          from_name: formState.name,
          reply_to: formState.email,
          message: formState.message,
          to_name: 'Emaar Landmark Limited Admin',
          source: 'Header Enquiry Modal'
        },
        'pwFViAXObrEFNBJdV'
      );

      setIsSubmitted(true);
      setTimeout(() => {
        setIsSubmitted(false);
        onClose();
        setFormState({ name: '', email: '', message: '' });
        setErrors({});
      }, 3000);
    } catch (error) {
      console.error('Email Delivery Failed:', error);
      setErrors({ global: 'Neural transmission failed. Please try again.' });
    } finally {
      setIsSending(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed inset-0 z-[101] flex items-center justify-center p-6 pointer-events-none"
          >
            <div className="bg-[#0a0a0a] border border-[#c5a059]/30 w-full max-w-xl p-8 md:p-12 relative pointer-events-auto overflow-hidden">
              <div className="absolute top-0 left-0 w-[2px] h-full bg-gradient-to-b from-[#c5a059] via-[#c5a059]/20 to-transparent"></div>
              
              <button 
                onClick={onClose}
                className="absolute top-6 right-6 text-white/40 hover:text-[#c5a059] transition-colors"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M18 6L6 18M6 6l12 12" />
                </svg>
              </button>

              <AnimatePresence mode="wait">
                {isSubmitted ? (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="py-12 text-center"
                  >
                    <div className="w-20 h-20 border border-[#c5a059] rounded-full flex items-center justify-center mx-auto mb-8">
                      <motion.svg 
                        initial={{ pathLength: 0 }}
                        animate={{ pathLength: 1 }}
                        transition={{ duration: 0.8 }}
                        width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#c5a059" strokeWidth="2"
                      >
                        <path d="M20 6L9 17l-5-5" />
                      </motion.svg>
                    </div>
                    <h3 className="text-3xl font-serif text-white mb-4">Transmission Successful</h3>
                    <p className="text-white/50 text-sm tracking-widest uppercase">Our concierge will contact you shortly.</p>
                  </motion.div>
                ) : (
                  <motion.div
                    key="form"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <span className="text-[#c5a059] uppercase tracking-[0.4em] text-[10px] mb-4 block">Personal Concierge</span>
                    <h2 className="text-4xl font-serif text-white mb-8">Begin Your Journey</h2>
                    
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="relative group">
                        <input
                          type="text"
                          disabled={isSending}
                          value={formState.name}
                          onChange={(e) => {
                            setFormState({ ...formState, name: e.target.value });
                            if (errors.name) setErrors({ ...errors, name: '' });
                          }}
                          placeholder="FULL NAME"
                          className={`w-full bg-transparent border-b ${errors.name ? 'border-red-500' : 'border-white/10'} py-4 text-sm tracking-widest text-white outline-none focus:border-[#c5a059] transition-colors uppercase placeholder:text-white/20`}
                        />
                        {errors.name && <p className="text-red-500 text-[9px] uppercase tracking-widest mt-1">{errors.name}</p>}
                      </div>

                      <div className="relative group">
                        <input
                          type="text"
                          disabled={isSending}
                          value={formState.email}
                          onChange={(e) => {
                            setFormState({ ...formState, email: e.target.value });
                            if (errors.email) setErrors({ ...errors, email: '' });
                          }}
                          placeholder="EMAIL ADDRESS"
                          className={`w-full bg-transparent border-b ${errors.email ? 'border-red-500' : 'border-white/10'} py-4 text-sm tracking-widest text-white outline-none focus:border-[#c5a059] transition-colors uppercase placeholder:text-white/20`}
                        />
                        {errors.email && <p className="text-red-500 text-[9px] uppercase tracking-widest mt-1">{errors.email}</p>}
                      </div>

                      <div className="relative group">
                        <textarea
                          rows={4}
                          disabled={isSending}
                          value={formState.message}
                          onChange={(e) => {
                            setFormState({ ...formState, message: e.target.value });
                            if (errors.message) setErrors({ ...errors, message: '' });
                          }}
                          placeholder="YOUR MESSAGE"
                          className={`w-full bg-transparent border-b ${errors.message ? 'border-red-500' : 'border-white/10'} py-4 text-sm tracking-widest text-white outline-none focus:border-[#c5a059] transition-colors uppercase placeholder:text-white/20 resize-none`}
                        />
                        {errors.message && <p className="text-red-500 text-[9px] uppercase tracking-widest mt-1">{errors.message}</p>}
                      </div>

                      {errors.global && <p className="text-red-500 text-[10px] uppercase tracking-widest text-center">{errors.global}</p>}

                      <button
                        type="submit"
                        disabled={isSending}
                        className="w-full py-5 bg-[#c5a059] text-black text-xs uppercase tracking-[0.3em] font-bold hover:bg-white transition-all duration-500 mt-8 relative overflow-hidden"
                      >
                        {isSending ? (
                           <div className="flex items-center justify-center gap-3">
                              <motion.div 
                                animate={{ rotate: 360 }}
                                transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                                className="w-4 h-4 border border-black border-t-transparent rounded-full"
                              />
                              <span>Establishing Neural Link...</span>
                           </div>
                        ) : 'Request Private Viewing'}
                      </button>
                    </form>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
