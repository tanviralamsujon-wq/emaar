
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AppView } from '../types';

interface FooterProps {
  onNavigate: (view: AppView) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [status, setStatus] = useState<'idle' | 'error' | 'success'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const validateEmail = (email: string) => {
    return String(email)
      .toLowerCase()
      .match(
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    
    if (!name.trim() || !email.trim()) {
      setStatus('error');
      setErrorMessage('Please complete all fields.');
      return;
    }

    if (!validateEmail(email)) {
      setStatus('error');
      setErrorMessage('Please provide a valid email address.');
      return;
    }

    setStatus('success');
    setTimeout(() => {
      setStatus('idle');
      setName('');
      setEmail('');
    }, 3000);
  };

  return (
    <footer id="contact-footer" className="bg-black/60 backdrop-blur-md border-t border-white/5 pt-24 pb-12 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-16 mb-24">
          <div className="lg:col-span-1 md:col-span-2">
            <h2 className="text-4xl font-serif text-[#c5a059] mb-6">EMAAR</h2>
            <p className="text-white/50 max-w-sm text-lg font-light leading-relaxed">
              Experience the pinnacle of luxury and architectural perfection. Join us in shaping the landscapes of tomorrow.
            </p>
            <div className="mt-12 flex gap-6">
              {['FB', 'IG', 'LI', 'TW'].map((social) => (
                <a key={social} href="#" className="w-10 h-10 border border-white/10 rounded-full flex items-center justify-center text-[10px] hover:border-[#c5a059] hover:text-[#c5a059] transition-all">
                  {social}
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-white uppercase tracking-widest text-xs mb-8">Navigation</h4>
            <ul className="space-y-4 text-white/50 text-sm tracking-wide">
              <li><button onClick={() => onNavigate('home')} className="hover:text-[#c5a059] transition-colors">Our Vision</button></li>
              <li><button onClick={() => onNavigate('portfolio')} className="hover:text-[#c5a059] transition-colors">Portfolio</button></li>
              <li><button onClick={() => onNavigate('careers')} className="hover:text-[#c5a059] transition-colors">Careers</button></li>
              <li><button onClick={() => onNavigate('contact')} className="hover:text-[#c5a059] transition-colors">Contact</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white uppercase tracking-widest text-xs mb-8">Headquarters</h4>
            <ul className="space-y-4 text-white/50 text-sm tracking-wide">
              <li>House: 171, Road: 03</li>
              <li>Mohakhali DOHS, Dhaka - 1206</li>
              <li>+880 1713 677 154</li>
              <li>info@emaarlandmark.com</li>
            </ul>
          </div>

          <div className="relative">
            <h4 className="text-white uppercase tracking-widest text-xs mb-8">Private Updates</h4>
            <AnimatePresence mode="wait">
              {status === 'success' ? (
                <motion.div 
                  key="success"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="bg-[#c5a059]/10 border border-[#c5a059]/30 p-4 rounded-sm"
                >
                  <p className="text-[#c5a059] text-xs uppercase tracking-widest leading-relaxed">
                    Welcome to the Inner Circle. <br />You are now registered.
                  </p>
                </motion.div>
              ) : (
                <motion.form 
                  key="form"
                  onSubmit={handleSubmit} 
                  className="space-y-4"
                >
                  <input
                    type="text"
                    placeholder="NAME"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-transparent border-b border-white/10 py-2 text-[10px] tracking-[0.2em] text-white outline-none focus:border-[#c5a059] transition-colors placeholder:text-white/20 uppercase"
                  />
                  <input
                    type="text"
                    placeholder="EMAIL"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-transparent border-b border-white/10 py-2 text-[10px] tracking-[0.2em] text-white outline-none focus:border-[#c5a059] transition-colors placeholder:text-white/20 uppercase"
                  />
                  <button
                    type="submit"
                    className="w-full mt-4 py-3 bg-white text-black text-[9px] uppercase tracking-[0.3em] font-bold hover:bg-[#c5a059] hover:text-white transition-all duration-500"
                  >
                    Subscribe
                  </button>
                </motion.form>
              )}
            </AnimatePresence>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center border-t border-white/5 pt-12 text-white/30 text-[10px] uppercase tracking-[0.2em]">
          <p>© 2024 Emaar Landmark Limited. All Rights Reserved.</p>
          <div className="flex gap-8 mt-6 md:mt-0">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
