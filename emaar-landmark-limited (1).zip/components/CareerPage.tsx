
import React from 'react';
import { motion } from 'framer-motion';
import { JOBS } from '../constants';

export const CareerPage: React.FC = () => {
  return (
    <div className="pt-32 pb-24 bg-[#050505] min-h-screen">
      {/* Career Hero */}
      <div className="max-w-7xl mx-auto px-6 mb-32">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-3xl"
        >
          <span className="text-[#c5a059] uppercase tracking-[0.5em] text-[10px] mb-4 block">Join Emaar Landmark</span>
          <h1 className="text-6xl md:text-8xl font-serif text-white mb-8">Architects of <br /><span className="italic font-light">Prosperity</span></h1>
          <p className="text-white/40 text-lg font-light leading-relaxed font-sans mb-12">
            "Emaar" means to build and to flourish. We are looking for visionaries who don't just see structures, but landscapes of human potential. Join our global collective in redefining the future skyline.
          </p>
          <div className="flex gap-12 border-t border-white/5 pt-12">
            <div>
               <h4 className="text-2xl font-serif text-white mb-1">Global</h4>
               <p className="text-[9px] uppercase tracking-widest text-[#c5a059]">Presence</p>
            </div>
            <div>
               <h4 className="text-2xl font-serif text-white mb-1">Impact</h4>
               <p className="text-[9px] uppercase tracking-widest text-[#c5a059]">Generational</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Video Transition */}
      <div className="h-[40vh] relative overflow-hidden mb-32 group">
        <video autoPlay loop muted playsInline className="w-full h-full object-cover brightness-50 grayscale group-hover:grayscale-0 transition-all duration-1000">
           <source src="https://assets.mixkit.co/videos/preview/mixkit-flying-through-a-futuristic-digital-city-at-night-42516-large.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 flex items-center justify-center">
           <div className="text-center">
              <span className="text-[10px] uppercase tracking-[0.8em] text-white/60 mb-4 block">Our Culture</span>
              <h3 className="text-4xl md:text-6xl font-serif text-white">Innovation First</h3>
           </div>
        </div>
      </div>

      {/* Listings */}
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid gap-8">
          {JOBS.map((job, i) => (
            <motion.div
              key={job.id}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group border border-white/5 bg-white/[0.02] p-8 md:p-12 flex flex-col md:flex-row justify-between items-start md:items-center gap-8 hover:border-[#c5a059]/40 transition-all cursor-pointer"
            >
              <div>
                <span className="text-[9px] uppercase tracking-widest text-[#c5a059] mb-3 block">{job.department}</span>
                <h3 className="text-3xl font-serif text-white mb-2">{job.title}</h3>
                <div className="flex items-center gap-6 text-[10px] text-white/40 tracking-widest uppercase">
                  <span>{job.location}</span>
                  <span className="w-1 h-1 rounded-full bg-[#c5a059]"></span>
                  <span>Full-Time</span>
                </div>
              </div>
              <button className="px-10 py-4 border border-white/10 text-white text-[10px] uppercase tracking-widest hover:bg-[#c5a059] hover:text-black transition-all">
                Submit Portfolio
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};
