
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PROPERTIES, PROPERTY_DETAILS } from '../constants';
import { PropertyDetailModal } from './PropertyDetailModal';

export const PortfolioSlider: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [direction, setDirection] = useState(0);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'info' | 'tour'>('info');

  useEffect(() => {
    const timer = setInterval(() => {
      if (!isDetailOpen) {
        next();
      }
    }, 7000);
    return () => clearInterval(timer);
  }, [isDetailOpen]);

  const next = () => {
    setDirection(1);
    setActiveIndex((prev) => (prev + 1) % PROPERTIES.length);
  };
  
  const prev = () => {
    setDirection(-1);
    setActiveIndex((prev) => (prev - 1 + PROPERTIES.length) % PROPERTIES.length);
  };

  const openDetails = (mode: 'info' | 'tour' = 'info') => {
    setModalMode(mode);
    setIsDetailOpen(true);
  };

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? '100%' : '-100%',
      opacity: 0,
      scale: 1.1,
    }),
    center: {
      x: 0,
      opacity: 1,
      scale: 1,
      transition: {
        duration: 1.2,
        ease: [0.16, 1, 0.3, 1] as any,
      }
    },
    exit: (direction: number) => ({
      x: direction < 0 ? '100%' : '-100%',
      opacity: 0,
      scale: 0.9,
      transition: {
        duration: 1.2,
        ease: [0.16, 1, 0.3, 1] as any,
      }
    })
  };

  const currentProperty = PROPERTIES[activeIndex];
  const currentDetails = PROPERTY_DETAILS[currentProperty.id];

  const subtitle = "Future Horizons";
  const subtitleChars = Array.from(subtitle);

  return (
    <section id="portfolio" className="py-24 bg-black/40 backdrop-blur-[2px] overflow-hidden border-y border-white/5">
      <div className="max-w-7xl mx-auto px-6 mb-16 flex flex-col md:flex-row justify-between items-start md:items-end gap-8">
        <div>
          <div className="overflow-hidden mb-4">
             <motion.div className="flex">
               {subtitleChars.map((char, i) => (
                 <motion.span
                   key={i}
                   initial={{ opacity: 0 }}
                   whileInView={{ opacity: 1 }}
                   viewport={{ once: true }}
                   transition={{ delay: 0.1 + (i * 0.03), duration: 0.3 }}
                   className="text-[#c5a059] uppercase tracking-[0.4em] text-[10px] md:text-xs font-bold inline-block whitespace-pre"
                 >
                   {char}
                 </motion.span>
               ))}
             </motion.div>
          </div>
          <div className="overflow-hidden">
            <motion.h2 
              initial={{ y: "100%", color: "rgba(255,255,255,0.15)" }}
              whileInView={{ y: 0, color: "rgba(255,255,255,1)" }}
              viewport={{ once: true }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="text-5xl md:text-7xl font-serif"
            >
              Our Upcoming Portfolio
            </motion.h2>
          </div>
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="text-white/40 mt-4 max-w-lg font-light font-sans tracking-wide"
          >
            As a new standard-bearer in real estate, we are meticulously curating a selection of landmarks that will redefine the skyline.
          </motion.p>
        </div>
        <div className="flex gap-4">
          <button onClick={prev} aria-label="Previous Property" className="w-14 h-14 border border-white/10 flex items-center justify-center hover:border-[#c5a059] hover:text-[#c5a059] transition-all rounded-full group">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="rotate-180 group-active:scale-90 transition-transform">
              <path d="M5 12H19M19 12L13 6M19 12L13 18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
          <button onClick={next} aria-label="Next Property" className="w-14 h-14 border border-white/10 flex items-center justify-center hover:border-[#c5a059] hover:text-[#c5a059] transition-all rounded-full group">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="group-active:scale-90 transition-transform">
              <path d="M5 12H19M19 12L13 6M19 12L13 18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>
      </div>

      <div className="relative h-[60vh] md:h-[85vh]">
        <AnimatePresence initial={false} custom={direction}>
          <motion.div
            key={currentProperty.id}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            className="absolute inset-0 px-0 md:px-6"
          >
            <motion.div 
              whileHover={{ scale: 1.005 }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="relative w-full h-full group overflow-hidden cursor-pointer shadow-[0_0_50px_rgba(0,0,0,0.5)]"
              onClick={() => openDetails('info')}
            >
              <img 
                src={currentProperty.image} 
                alt={currentProperty.title}
                className="w-full h-full object-cover brightness-[0.35] group-hover:scale-105 transition-transform duration-[8s] ease-out group-hover:brightness-[0.5]"
              />
              
              <div className="absolute inset-0 shadow-[inset_0_0_100px_rgba(0,0,0,0.8)] group-hover:shadow-[inset_0_0_150px_rgba(197,160,89,0.2)] transition-shadow duration-1000 pointer-events-none"></div>
              <div className="absolute inset-0 bg-[#c5a059]/0 group-hover:bg-[#c5a059]/[0.02] transition-colors duration-1000 pointer-events-none"></div>
              <div className="absolute inset-0 border border-white/5 group-hover:border-[#c5a059]/30 transition-all duration-1000 m-4 md:m-8 pointer-events-none"></div>

              <div className="absolute top-12 right-12 z-10 flex gap-4">
                <span className="px-4 py-1 border border-[#c5a059]/40 text-[#c5a059] text-[10px] tracking-widest uppercase bg-black/60 backdrop-blur-md group-hover:border-[#c5a059] transition-colors duration-500">Conceptual Stage</span>
              </div>
              
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-all duration-700 z-20 pointer-events-none translate-y-4 group-hover:translate-y-0">
                <div className="w-28 h-28 rounded-full border border-[#c5a059]/30 flex items-center justify-center bg-black/20 backdrop-blur-md shadow-[0_0_30px_rgba(197,160,89,0.1)]">
                   <div className="relative flex flex-col items-center">
                     <motion.svg 
                        animate={{ y: [0, -3, 0] }}
                        transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
                        width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#c5a059" strokeWidth="1" className="mb-2"
                     >
                        <path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                     </motion.svg>
                     <span className="text-[8px] text-white uppercase tracking-[0.3em] text-center font-light">Explore</span>
                   </div>
                </div>
              </div>

              <div className="absolute inset-0 flex flex-col justify-end p-8 md:p-24 bg-gradient-to-t from-black via-black/20 to-transparent group-hover:from-black/90 transition-all duration-700">
                <motion.div
                  initial={{ y: 40, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.6, duration: 0.8, ease: "easeOut" }}
                  className="group-hover:-translate-y-4 transition-transform duration-1000 ease-[0.16,1,0.3,1]"
                >
                  <span className="text-[#c5a059] font-serif italic text-xl md:text-2xl mb-2 block group-hover:text-white transition-colors duration-700">{currentProperty.category}</span>
                  <h3 className="text-5xl md:text-7xl lg:text-8xl font-serif mb-6 leading-none group-hover:luxury-gradient transition-all duration-1000">{currentProperty.title}</h3>
                  <p className="text-white/60 text-base md:text-xl max-w-2xl mb-10 font-light tracking-wide leading-relaxed group-hover:text-white/90 transition-colors duration-700">
                    {currentProperty.description}
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <button 
                      onClick={(e) => { e.stopPropagation(); openDetails('info'); }}
                      className="px-10 py-4 bg-[#c5a059] text-black text-[10px] md:text-xs uppercase tracking-[0.3em] font-bold hover:bg-white hover:scale-105 active:scale-95 transition-all duration-500 shadow-[0_0_20px_rgba(197,160,89,0.2)]"
                    >
                      View Blueprint
                    </button>
                    {currentDetails.virtualTourUrl && (
                      <button 
                        onClick={(e) => { e.stopPropagation(); openDetails('tour'); }}
                        className="px-10 py-4 border border-[#c5a059] text-[#c5a059] text-[10px] md:text-xs uppercase tracking-[0.3em] font-bold hover:bg-[#c5a059] hover:text-black hover:scale-105 active:scale-95 transition-all duration-500 group/tour flex items-center gap-3"
                      >
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" className="group-hover/tour:rotate-12 transition-transform">
                          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" />
                        </svg>
                        Virtual Tour
                      </button>
                    )}
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="max-w-7xl mx-auto px-6 mt-16 flex items-center gap-12">
        <span className="text-xs text-white/40 tracking-[0.4em] font-light">
          {String(activeIndex + 1).padStart(2, '0')} <span className="mx-2">/</span> {String(PROPERTIES.length).padStart(2, '0')}
        </span>
        <div className="flex-1 h-[1px] bg-white/5 relative overflow-hidden">
          <motion.div 
            className="absolute top-0 left-0 h-full bg-[#c5a059]"
            initial={{ width: 0 }}
            animate={{ width: `${((activeIndex + 1) / PROPERTIES.length) * 100}%` }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
          />
        </div>
      </div>

      <PropertyDetailModal 
        property={currentProperty}
        details={currentDetails}
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
        initialMode={modalMode}
      />
    </section>
  );
};
