
import React from 'react';
import { motion } from 'framer-motion';

export const HeritageSection: React.FC = () => {
  const subtitle = "The Embodiment of Emaar";
  const subtitleChars = Array.from(subtitle);

  return (
    <section id="heritage" className="relative min-h-screen py-32 flex items-center overflow-hidden border-t border-white/5">
      {/* Cinematic Background: Requested YouTube Video as Full Section Background */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 w-full h-full scale-[1.3] md:scale-110">
          <iframe
            className="w-full h-full grayscale brightness-50 contrast-125 object-cover"
            src="https://www.youtube.com/embed/l6EzZafb1Pk?autoplay=1&mute=1&loop=1&playlist=l6EzZafb1Pk&controls=0&showinfo=0&rel=0&iv_load_policy=3&modestbranding=1&enablejsapi=1"
            title="Emaar Corporate Vision"
            frameBorder="0"
            allow="autoplay; encrypted-media"
            allowFullScreen
          ></iframe>
        </div>
        {/* Dark Overlays for Text Legibility */}
        <div className="absolute inset-0 bg-gradient-to-b from-black via-black/60 to-black"></div>
        <div className="absolute inset-0 bg-black/40"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10 w-full">
        <div className="text-center mb-24">
          <motion.div
            viewport={{ once: true }}
            className="mb-12"
          >
            <div className="overflow-hidden mb-8">
              <motion.div className="flex justify-center">
                {subtitleChars.map((char, i) => (
                  <motion.span
                    key={i}
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.1 + (i * 0.03), duration: 0.3 }}
                    className="text-[#c5a059] uppercase tracking-[0.6em] text-[10px] md:text-xs font-bold inline-block whitespace-pre"
                  >
                    {char}
                  </motion.span>
                ))}
              </motion.div>
            </div>

            <motion.h2 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 0.05, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
              className="text-6xl md:text-9xl font-serif italic font-light leading-none select-none tracking-tighter"
            >
              P R O S P E R I T Y
            </motion.h2>

            <div className="mt-[-2rem] md:mt-[-4.5rem] overflow-hidden">
               <motion.h3 
                 initial={{ y: "100%", color: "rgba(255,255,255,0.15)" }}
                 whileInView={{ y: 0, color: "rgba(255,255,255,1)" }}
                 viewport={{ once: true }}
                 transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
                 className="text-5xl md:text-7xl font-serif"
               >
                 A Testament to Flourishing
               </motion.h3>
            </div>

            <motion.p 
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6 }}
              className="text-white/60 mt-8 max-w-2xl mx-auto font-light text-lg font-sans tracking-wide leading-relaxed"
            >
              To build is to settle, and to settle is to thrive. At Emaar Landmark Limited, we breathe life into the sacred promise of architecture—creating environments where prosperity takes root and legacies are forged for generations.
            </motion.p>
          </motion.div>

          {/* Stats / Pillars Section Layered on Video */}
          <div className="grid md:grid-cols-3 gap-12 text-left mt-24">
            {[
              { title: 'The Philosophy', value: 'Infinite', label: 'Cycle of Flourishing' },
              { title: 'The Standard', value: 'Mastery', label: 'Artisanal Perfection' },
              { title: 'The Horizon', value: 'Global', label: 'Landmark Significance' }
            ].map((stat, idx) => (
              <motion.div
                key={stat.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.8 + (idx * 0.2), duration: 0.8 }}
                className="backdrop-blur-sm bg-black/20 border-l border-[#c5a059]/30 p-8 group hover:border-[#c5a059] hover:bg-black/40 transition-all duration-700"
              >
                <h4 className="text-[#c5a059] uppercase tracking-widest text-[10px] mb-4 font-sans font-bold">{stat.title}</h4>
                <p className="text-4xl md:text-5xl font-serif mb-2 text-white group-hover:text-[#c5a059] transition-colors duration-500">{stat.value}</p>
                <p className="text-white/40 text-[10px] uppercase tracking-widest font-sans font-light">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Decorative HUD Elements */}
      <div className="absolute bottom-12 left-12 flex items-center gap-6 z-10 pointer-events-none hidden md:flex">
        <div className="w-2.5 h-2.5 rounded-full bg-[#c5a059] animate-pulse"></div>
        <span className="text-[10px] uppercase tracking-[0.5em] text-white/40 font-bold">Live Corporate Feed</span>
      </div>

      <div className="absolute top-12 right-12 flex flex-col items-end gap-2 z-10 pointer-events-none opacity-20 hidden md:flex">
        <div className="w-32 h-[1px] bg-[#c5a059]"></div>
        <span className="text-[8px] uppercase tracking-widest text-white">Transmission: Stable</span>
      </div>
    </section>
  );
};
