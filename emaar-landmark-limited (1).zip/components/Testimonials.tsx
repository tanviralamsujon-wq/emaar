
import React from 'react';
import { motion } from 'framer-motion';
import { TESTIMONIALS } from '../constants';

export const Testimonials: React.FC = () => {
  const subtitle = "Endorsements";
  const subtitleChars = Array.from(subtitle);

  return (
    <section className="py-32 bg-transparent overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <div className="overflow-hidden mb-4">
             <motion.div className="flex justify-center">
               {subtitleChars.map((char, i) => (
                 <motion.span
                   key={i}
                   initial={{ opacity: 0 }}
                   whileInView={{ opacity: 1 }}
                   viewport={{ once: true }}
                   transition={{ delay: 0.1 + (i * 0.03), duration: 0.3 }}
                   className="text-[#c5a059] uppercase tracking-[0.4em] text-[10px] font-bold inline-block whitespace-pre"
                 >
                   {char}
                 </motion.span>
               ))}
             </motion.div>
          </div>
          <div className="overflow-hidden">
            <motion.h2 
              initial={{ y: "100%", color: "rgba(255,255,255,0.15)" }}
              whileInView={{ y: 0, color: "rgba(255,255,255,1)" }}
              viewport={{ once: true }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="text-4xl md:text-6xl font-serif"
            >
              Voices of Vision
            </motion.h2>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: i * 0.2 }}
              className="bg-black/60 backdrop-blur-md p-12 relative group border border-white/5 hover:border-[#c5a059]/30 transition-all duration-500"
            >
              <div className="text-[#c5a059] text-6xl font-serif absolute top-4 left-8 opacity-10 group-hover:opacity-20 transition-opacity">"</div>
              <p className="text-white/70 italic text-lg leading-relaxed mb-12 relative z-10">
                {t.quote}
              </p>
              <div className="flex flex-col">
                <span className="text-white font-serif text-xl mb-1">{t.name}</span>
                <span className="text-[#c5a059] text-[10px] uppercase tracking-widest">{t.role}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
