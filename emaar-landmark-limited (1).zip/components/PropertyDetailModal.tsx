
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Property, PropertyDetail, Hotspot } from '../types';

interface PropertyDetailModalProps {
  property: Property | null;
  details: PropertyDetail | null;
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'info' | 'tour';
}

export const PropertyDetailModal: React.FC<PropertyDetailModalProps> = ({ 
  property, 
  details, 
  isOpen, 
  onClose,
  initialMode = 'info'
}) => {
  const [mode, setMode] = useState<'info' | 'tour'>(initialMode);
  const [isLoaded, setIsLoaded] = useState(false);
  const [activeHotspot, setActiveHotspot] = useState<string | null>(null);

  if (!property || !details) return null;

  const handleClose = () => {
    setMode('info');
    setIsLoaded(false);
    setActiveHotspot(null);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="fixed inset-0 z-[110] bg-black/95 backdrop-blur-xl"
          />
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-y-0 right-0 z-[111] w-full lg:w-[60vw] bg-[#050505] border-l border-[#c5a059]/30 overflow-y-auto"
          >
            <div className="p-8 md:p-16 h-full flex flex-col">
              <div className="flex justify-between items-center mb-12 shrink-0">
                <button 
                  onClick={handleClose}
                  className="flex items-center gap-4 text-white/40 hover:text-[#c5a059] transition-colors group"
                >
                  <div className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center group-hover:border-[#c5a059]">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <path d="M18 6L6 18M6 6l12 12" />
                    </svg>
                  </div>
                  <span className="text-[10px] uppercase tracking-widest font-sans">Close</span>
                </button>

                {details.virtualTourUrl && (
                  <div className="flex border border-white/10 p-1 rounded-full bg-white/5">
                    <button 
                      onClick={() => setMode('info')}
                      className={`px-4 py-1.5 rounded-full text-[9px] uppercase tracking-widest transition-all ${mode === 'info' ? 'bg-[#c5a059] text-black' : 'text-white/40 hover:text-white'}`}
                    >
                      Specifications
                    </button>
                    <button 
                      onClick={() => { setMode('tour'); setIsLoaded(false); }}
                      className={`px-4 py-1.5 rounded-full text-[9px] uppercase tracking-widest transition-all ${mode === 'tour' ? 'bg-[#c5a059] text-black' : 'text-white/40 hover:text-white'}`}
                    >
                      {details.virtualTourType === '3d' ? '3D Interface' : 'Virtual Tour'}
                    </button>
                  </div>
                )}
              </div>

              <AnimatePresence mode="wait">
                {mode === 'info' ? (
                  <motion.div 
                    key="info"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="grid lg:grid-cols-2 gap-16"
                  >
                    <div>
                      <span className="text-[#c5a059] uppercase tracking-[0.4em] text-[10px] mb-4 block font-sans">{property.category} • {details.completionDate}</span>
                      <h2 className="text-5xl md:text-7xl font-serif text-white mb-8 leading-tight">{property.title}</h2>
                      <p className="text-white/60 text-lg font-light leading-relaxed mb-12 font-sans">
                        {property.description}
                      </p>

                      <div className="space-y-12 font-sans">
                        <div>
                          <h4 className="text-white uppercase tracking-widest text-xs mb-6 border-b border-[#c5a059]/20 pb-2 inline-block">Key Distinctions</h4>
                          <ul className="space-y-4">
                            {details.usps.map((usp, i) => (
                              <li key={i} className="flex gap-4 text-white/50 text-sm font-light">
                                <span className="text-[#c5a059]">•</span>
                                {usp}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h4 className="text-white uppercase tracking-widest text-xs mb-6 border-b border-[#c5a059]/20 pb-2 inline-block">Luxury Amenities</h4>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            {details.amenities.map((amenity, i) => (
                              <div key={i} className="p-4 bg-white/5 border border-white/5 rounded-sm text-white/70 text-xs tracking-wide">
                                {amenity}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-12">
                      <div className="relative group overflow-hidden">
                        <img 
                          src={details.blueprintImage} 
                          alt="Blueprint Concept" 
                          className="w-full h-[400px] object-cover brightness-50 group-hover:brightness-75 transition-all duration-700"
                        />
                        <div className="absolute inset-0 border border-[#c5a059]/10 group-hover:border-[#c5a059]/30 transition-colors pointer-events-none"></div>
                        <div className="absolute bottom-6 left-6">
                          <span className="text-[10px] uppercase tracking-widest bg-black/60 backdrop-blur-md px-3 py-1 border border-[#c5a059]/20 text-white font-sans">Architectural Visualization</span>
                        </div>
                      </div>

                      <div>
                        <h4 className="text-white uppercase tracking-widest text-xs mb-6 border-b border-[#c5a059]/20 pb-2 inline-block font-sans">Design Philosophy</h4>
                        <p className="text-white/40 text-sm italic leading-relaxed font-serif">
                          "{details.blueprintDescription}"
                        </p>
                      </div>

                      <div className="pt-8 flex flex-col gap-4 font-sans">
                        <button className="w-full py-5 bg-[#c5a059] text-black text-xs uppercase tracking-[0.3em] font-bold hover:bg-white transition-all duration-500">
                          Request Comprehensive Brochure
                        </button>
                        {details.virtualTourUrl && (
                          <button 
                            onClick={() => setMode('tour')}
                            className="w-full py-5 border border-white/10 text-white text-xs uppercase tracking-[0.3em] font-bold hover:bg-white hover:text-black transition-all duration-500"
                          >
                            Launch {details.virtualTourType === '3d' ? '3D Immersive Experience' : 'Virtual Walkthrough'}
                          </button>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div 
                    key="tour"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="flex-1 flex flex-col overflow-hidden"
                  >
                    <div className="mb-8 shrink-0">
                       <span className="text-[#c5a059] uppercase tracking-[0.4em] text-[10px] mb-2 block font-sans">
                         {details.virtualTourType === '3d' ? 'Immersive 3D Spatial Environment' : 'Cinematic Experience'}
                       </span>
                       <h2 className="text-4xl font-serif text-white">{property.title} • {details.virtualTourType === '3d' ? 'Spatial View' : 'Walkthrough'}</h2>
                    </div>
                    
                    <div className="flex-1 bg-black rounded-sm overflow-hidden border border-[#c5a059]/20 relative">
                       {!isLoaded && (
                         <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-black">
                            <motion.div 
                              animate={{ rotate: 360 }}
                              transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                              className="w-12 h-12 border-2 border-[#c5a059]/20 border-t-[#c5a059] rounded-full mb-4"
                            />
                            <span className="text-[10px] uppercase tracking-[0.3em] text-[#c5a059] animate-pulse font-sans">Initializing Neural Link...</span>
                         </div>
                       )}

                       {/* Enhanced Interactive Hotspots Overlays with Technical Data Extraction */}
                       {details.virtualTourType === '3d' && isLoaded && details.hotspots && (
                         <div className="absolute inset-0 z-40 pointer-events-none">
                            {details.hotspots.map((hs) => (
                              <div 
                                key={hs.id}
                                className="absolute pointer-events-auto"
                                style={{ top: hs.top, left: hs.left }}
                              >
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setActiveHotspot(activeHotspot === hs.id ? null : hs.id);
                                  }}
                                  className="relative flex items-center justify-center group"
                                >
                                  {/* Luxurious Multi-Ring Pulsing Marker */}
                                  <div className="relative flex items-center justify-center">
                                    <motion.div 
                                      animate={{ scale: [1, 2.2], opacity: [0.5, 0] }}
                                      transition={{ repeat: Infinity, duration: 3, ease: "easeOut" }}
                                      className="absolute w-12 h-12 rounded-full border border-[#c5a059] shadow-[0_0_20px_rgba(197,160,89,0.2)]"
                                    />
                                    <motion.div 
                                      animate={{ scale: [1, 1.3, 1] }}
                                      transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
                                      className={`w-10 h-10 rounded-full border border-[#c5a059]/30 bg-black/40 backdrop-blur-md flex items-center justify-center transition-all duration-700 ${activeHotspot === hs.id ? 'border-[#c5a059] bg-[#c5a059]/30 scale-125 ring-4 ring-[#c5a059]/10' : 'group-hover:border-[#c5a059] group-hover:scale-110'}`}
                                    >
                                      <div className={`w-2.5 h-2.5 rounded-full transition-all duration-500 shadow-[0_0_12px_rgba(197,160,89,1)] ${activeHotspot === hs.id ? 'bg-white' : 'bg-[#c5a059]'}`} />
                                    </motion.div>
                                  </div>
                                  
                                  <AnimatePresence>
                                    {activeHotspot === hs.id && (
                                      <motion.div
                                        initial={{ opacity: 0, x: 40, scale: 0.9, filter: 'blur(10px)' }}
                                        animate={{ opacity: 1, x: 0, scale: 1, filter: 'blur(0px)' }}
                                        exit={{ opacity: 0, x: 40, scale: 0.9, filter: 'blur(10px)' }}
                                        className="absolute left-16 w-96 bg-black/95 backdrop-blur-3xl border border-[#c5a059]/40 shadow-[0_0_80px_rgba(0,0,0,0.9),inset_0_0_30px_rgba(197,160,89,0.05)] text-left overflow-hidden"
                                      >
                                        {/* Scanner Line Effect */}
                                        <motion.div 
                                          initial={{ top: "-100%" }}
                                          animate={{ top: "100%" }}
                                          transition={{ repeat: Infinity, duration: 3, ease: "linear" }}
                                          className="absolute left-0 right-0 h-[1px] bg-[#c5a059]/40 z-10"
                                        />

                                        <div className="absolute -left-[10px] top-8 w-5 h-5 bg-black border-l border-b border-[#c5a059]/40 rotate-45"></div>
                                        
                                        <div className="p-8 relative">
                                          <div className="flex items-center gap-4 mb-6">
                                            <div className="w-1.5 h-10 bg-[#c5a059] shadow-[0_0_12px_rgba(197,160,89,0.6)]"></div>
                                            <div>
                                              <span className="text-[8px] text-[#c5a059]/60 tracking-[0.4em] uppercase font-sans block mb-1">Architecture Node</span>
                                              <h5 className="text-[#c5a059] uppercase tracking-[0.2em] text-xs font-bold font-sans">{hs.title}</h5>
                                            </div>
                                          </div>
                                          
                                          <p className="text-white/80 text-[12px] leading-relaxed font-light font-sans tracking-wide mb-8">
                                            {hs.description}
                                          </p>

                                          {/* Technical Data Grid */}
                                          {hs.specs && (
                                            <div className="grid grid-cols-1 gap-4 py-6 border-y border-white/5">
                                              {hs.specs.map((spec, idx) => (
                                                <div key={idx} className="flex justify-between items-end group/spec">
                                                  <span className="text-[9px] text-white/30 tracking-widest uppercase font-sans">{spec.label}</span>
                                                  <div className="flex-1 border-b border-dotted border-white/10 mx-4 mb-1 group-hover/spec:border-white/30 transition-colors"></div>
                                                  <span className="text-[10px] text-[#c5a059] tracking-wider uppercase font-bold font-sans">{spec.value}</span>
                                                </div>
                                              ))}
                                            </div>
                                          )}
                                          
                                          <div className="mt-8 flex justify-between items-center">
                                            <div className="flex gap-2">
                                              <div className="w-1 h-1 rounded-full bg-[#c5a059] animate-ping"></div>
                                              <span className="text-[8px] text-white/30 tracking-widest uppercase font-sans">System Nominal</span>
                                            </div>
                                            <button className="text-[9px] text-white uppercase tracking-widest border border-white/10 px-4 py-2 hover:bg-[#c5a059] hover:text-black hover:border-transparent transition-all font-bold font-sans">
                                              Full Telemetry
                                            </button>
                                          </div>
                                        </div>
                                      </motion.div>
                                    )}
                                  </AnimatePresence>
                                </button>
                              </div>
                            ))}
                         </div>
                       )}

                       {/* Futuristic HUD Overlays */}
                       {details.virtualTourType === '3d' && isLoaded && (
                         <div className="absolute inset-0 pointer-events-none z-20">
                            {/* HUD Corners with animation */}
                            <motion.div 
                              initial={{ opacity: 0, scale: 1.1 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ duration: 1.5 }}
                              className="absolute inset-0"
                            >
                              <div className="absolute top-10 left-10 w-16 h-16 border-t-2 border-l-2 border-[#c5a059]/20"></div>
                              <div className="absolute top-10 right-10 w-16 h-16 border-t-2 border-r-2 border-[#c5a059]/20"></div>
                              <div className="absolute bottom-10 left-10 w-16 h-16 border-b-2 border-l-2 border-[#c5a059]/20"></div>
                              <div className="absolute bottom-10 right-10 w-16 h-16 border-b-2 border-r-2 border-[#c5a059]/20"></div>
                            </motion.div>
                            
                            {/* Animated Data sidebars */}
                            <div className="absolute right-12 top-1/2 -translate-y-1/2 flex flex-col gap-12 opacity-20 font-sans">
                               <div className="text-[9px] uppercase tracking-[0.5em] text-right space-y-2">
                                  <p className="text-[#c5a059]">COORDS: 42.1 / 88.0</p>
                                  <p>ALTITUDE: 442M</p>
                                  <p>STABILITY: CALIBRATED</p>
                               </div>
                               <div className="text-[9px] uppercase tracking-[0.5em] text-right space-y-2">
                                  <p className="text-[#c5a059]">RENDER: ULTRA-FID</p>
                                  <p>RAY_TRACING: ACTIVE</p>
                                  <p>FRAME_RATE: 120 FPS</p>
                               </div>
                            </div>

                            <motion.div 
                              initial={{ opacity: 0, y: -20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 0.5 }}
                              className="absolute top-12 left-1/2 -translate-x-1/2 flex items-center gap-6 bg-black/40 backdrop-blur-2xl border border-[#c5a059]/30 px-10 py-4 rounded-full"
                            >
                               <div className="w-2.5 h-2.5 rounded-full bg-[#c5a059] shadow-[0_0_12px_rgba(197,160,89,1)] animate-pulse"></div>
                               <span className="text-[11px] uppercase tracking-[0.5em] text-white font-sans font-bold">Spatial Interface Authenticated</span>
                            </motion.div>

                            <div className="absolute bottom-12 left-1/2 -translate-x-1/2 text-[10px] uppercase tracking-[0.4em] text-white/20 font-sans text-center">
                               Initiate element selection for technical data extraction
                            </div>
                         </div>
                       )}

                       {details.virtualTourType === 'video' ? (
                         <video 
                           src={details.virtualTourUrl} 
                           autoPlay 
                           loop 
                           controls 
                           onLoadedData={() => setIsLoaded(true)}
                           className="w-full h-full object-cover"
                         />
                       ) : (
                         <iframe 
                           src={details.virtualTourUrl} 
                           onLoad={() => setIsLoaded(true)}
                           className="w-full h-full border-none"
                           allowFullScreen
                           allow="xr-spatial-tracking; vr; gyroscope; accelerometer;"
                         />
                       )}

                       <div className="absolute bottom-10 left-10 flex items-center gap-5 z-30 font-sans">
                          <div className={`w-3 h-3 rounded-full ${details.virtualTourType === '3d' ? 'bg-[#c5a059]' : 'bg-red-500'} animate-pulse shadow-[0_0_15px_rgba(197,160,89,0.8)]`}></div>
                          <span className="text-[11px] uppercase tracking-[0.4em] text-white/80 font-bold">
                            {details.virtualTourType === '3d' ? 'Neural Visualization Active' : 'Cinematic Feed'}
                          </span>
                       </div>
                    </div>

                    <div className="mt-12 flex justify-center shrink-0">
                       <button 
                         onClick={() => { setMode('info'); setActiveHotspot(null); }}
                         className="flex items-center gap-4 text-[#c5a059] hover:text-white transition-all group font-sans"
                       >
                         <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="group-hover:-translate-x-3 transition-transform">
                           <path d="M19 12H5M5 12L12 19M5 12L12 5" />
                         </svg>
                         <span className="text-[11px] uppercase tracking-[0.4em] font-bold">Return to Technical Architecture</span>
                       </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
