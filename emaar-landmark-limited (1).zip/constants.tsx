
import { Property, PropertyDetail, NavItem, JobOpening } from './types';

export const NAV_ITEMS: NavItem[] = [
  { label: 'The Vision', href: 'home' },
  { label: 'Portfolio', href: 'portfolio' },
  { label: 'Careers', href: 'careers' },
  { label: 'Contact', href: 'contact' },
];

export const PROPERTIES: Property[] = [
  {
    id: '1',
    title: 'The Eternal Spire',
    location: 'Metropolitan Core',
    image: 'https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&q=80&w=1600',
    description: 'A conceptual marvel destined to be our flagship luxury apartment residence. Currently in the final design phase.',
    category: 'Apartments'
  },
  {
    id: '2',
    title: 'Emaar Nexus',
    location: 'Innovation District',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1600',
    description: 'A premium hotel share opportunity within a future-ready commercial ecosystem designed for global travelers.',
    category: 'Hotel Share'
  },
  {
    id: '3',
    title: 'Solstice Gardens',
    location: 'Eco-Enclave',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=1600',
    description: 'An exclusive resort share sanctuary where luxury living meets sustainable botanical architecture.',
    category: 'Resort Share'
  },
  {
    id: '4',
    title: 'The Verdant Oasis',
    location: 'Palm District',
    image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=1600',
    description: 'Prime luxury land plots nestled within a private botanical forest, offering absolute seclusion for bespoke builds.',
    category: 'Land'
  },
  {
    id: '5',
    title: 'Summit Horizon',
    location: 'Financial Hub',
    image: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&q=80&w=1600',
    description: 'High-yield hotel share units featuring world-class facilities and panoramic views of the city skyline.',
    category: 'Hotel Share'
  },
  {
    id: '6',
    title: 'Lumina Valley',
    location: 'Waterfront',
    image: 'https://images.unsplash.com/photo-1518005020251-098c17822bd4?auto=format&fit=crop&q=80&w=1600',
    description: 'Collaborative land share investments in a vibrant waterfront destination blending retail and premium leisure.',
    category: 'Land Share'
  }
];

export const PROPERTY_DETAILS: Record<string, PropertyDetail> = {
  '1': {
    id: '1',
    usps: [
      'Tallest residential structure in the Metropolitan Core',
      '360-degree panoramic sky gardens',
      'Proprietary smart-climate glass facade'
    ],
    amenities: [
      'Infinity edge sky-pool on 88th floor',
      'Private biometric elevator access',
      'Atmospheric wellness spa and cryogenic suites'
    ],
    blueprintDescription: 'The architecture utilizes a triple-helix load-bearing structure to allow for column-free living spaces and expansive floor-to-ceiling vistas.',
    blueprintImage: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&q=80&w=1000',
    completionDate: 'Q4 2028 (Projected)',
    virtualTourUrl: 'https://sketchfab.com/models/05307a0164c049079366e6c8695f2694/embed?autostart=1&ui_controls=0&ui_infos=0&ui_inspector=0&ui_stop=0&ui_watermark=0&ui_hint=2',
    virtualTourType: '3d',
    hotspots: [
      { 
        id: 'hs-1', 
        top: '25%', 
        left: '50%', 
        title: 'Neural Facade', 
        description: 'Adaptive crystalline glazing that adjusts opacity based on solar intensity.',
        specs: [
          { label: 'MATERIAL', value: 'Carbon Nano-Glaze' },
          { label: 'EFFICIENCY', value: '98.4% Solar Ret.' },
          { label: 'MODES', value: 'Auto-Privacy 3.0' }
        ]
      }
    ]
  },
  '2': {
    id: '2',
    usps: ['AI-integrated workspace', 'Zero-carbon footprint', 'Modular configurations'],
    amenities: ['Holographic center', 'Drone pads', 'Automated café'],
    blueprintDescription: 'Designed around a central light-well that channels natural sunlight deep into the subterranean levels.',
    blueprintImage: 'https://images.unsplash.com/photo-1511818966892-d7d671e672a2?auto=format&fit=crop&q=80&w=1000',
    completionDate: 'Q2 2027 (Projected)',
    virtualTourUrl: 'https://assets.mixkit.co/videos/preview/mixkit-futuristic-city-street-at-night-42515-large.mp4',
    virtualTourType: 'video'
  },
  '3': {
    id: '3',
    usps: ['Hydroponic walls', 'Rainwater filtration', 'Thermal cooling'],
    amenities: ['Organic garden', 'EV charging', 'Bio-adaptive library'],
    blueprintDescription: 'Features interlocking terrace modules that maximize cross-ventilation.',
    blueprintImage: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1000',
    completionDate: 'Q1 2029 (Projected)',
    virtualTourUrl: 'https://assets.mixkit.co/videos/preview/mixkit-camera-moves-through-a-modern-office-with-lots-of-plants-42521-large.mp4',
    virtualTourType: 'video'
  },
  '4': {
    id: '4',
    usps: ['Private forest estates', 'Wildlife integration', 'Smart perimeter security'],
    amenities: ['Zen meditation pond', 'Organic chef services', 'Private horse stables'],
    blueprintDescription: 'Villas are oriented to follow the natural topography, minimizing environmental disruption while maximizing cross-breeze.',
    blueprintImage: 'https://images.unsplash.com/photo-1480074568708-e7b720bb3f09?auto=format&fit=crop&q=80&w=1000',
    completionDate: 'Q3 2027 (Projected)',
    virtualTourUrl: 'https://assets.mixkit.co/videos/preview/mixkit-sunlight-streaming-into-a-modern-luxury-living-room-42531-large.mp4',
    virtualTourType: 'video'
  },
  '5': {
    id: '5',
    usps: ['Tier-IV data center', 'Heliport access', 'Parametric facade'],
    amenities: ['Private member lounge', 'Hyper-loop terminal', 'Wellness performance center'],
    blueprintDescription: 'The central core is reinforced with carbon-fiber composites, allowing for unmatched structural slimness and efficiency.',
    blueprintImage: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1000',
    completionDate: 'Q2 2028 (Projected)',
    virtualTourType: 'video',
    virtualTourUrl: 'https://assets.mixkit.co/videos/preview/mixkit-futuristic-city-street-at-night-42515-large.mp4'
  },
  '6': {
    id: '6',
    usps: ['Water-recycling systems', 'Autonomous transit loop', 'Digital twin management'],
    amenities: ['Floating boardwalk', 'Interactive light art', 'Curated retail promenade'],
    blueprintDescription: 'Masterplan focuses on "soft urbanism," prioritizing pedestrian mobility and micro-climate management through water features.',
    blueprintImage: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?auto=format&fit=crop&q=80&w=1000',
    completionDate: 'Q1 2030 (Projected)',
    virtualTourType: 'video',
    virtualTourUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-city-skyscrapers-and-buildings-at-night-42512-large.mp4'
  }
};

export const JOBS: JobOpening[] = [
  {
    id: 'j1',
    title: 'Principal Futurist Architect',
    department: 'Design & Innovation',
    location: 'Metropolitan Core',
    description: 'Seeking a visionary to lead our generative architecture division. Must have experience in parametric design and sustainable urbanism.'
  },
  {
    id: 'j2',
    title: 'Luxury Concierge Director',
    department: 'Client Relations',
    location: 'Innovation District',
    description: 'Curate the ultimate living experience for our residents across all Emaar landmarks.'
  },
  {
    id: 'j3',
    title: 'Smart Systems Engineer',
    department: 'Technology',
    location: 'Metropolitan Core',
    description: 'Integrate AI and IoT frameworks into our futuristic glass facades and mass damper systems.'
  }
];

export const TESTIMONIALS = [
  { name: "Sir Alistair Vance", role: "Chief Architect, Global Urbanism", quote: "Emaar Landmark Limited represents a paradigm shift. They aren't just building; they are architecting prosperity for future generations." },
  { name: "Elena Moretti", role: "Luxury Lifestyle Consultant", quote: "The vision presented by Emaar is unlike anything I've seen in the new market. Their commitment to the Arabic essence of 'Emaar' is truly profound." },
  { name: "Marcus Thorne", role: "Sustainability Director, GreenScape", quote: "Collaborating on their conceptual frameworks has shown me a company that values planetary health as much as architectural grandeur." }
];
